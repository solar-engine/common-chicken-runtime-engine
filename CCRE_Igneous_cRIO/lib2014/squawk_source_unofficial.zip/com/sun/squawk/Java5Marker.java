//if[JAVA5SYNTAX]
package com.sun.squawk;

@Java5Marker
public @interface Java5Marker {

    public String value() default "";
    
}
